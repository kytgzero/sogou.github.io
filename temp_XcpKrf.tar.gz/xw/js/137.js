(function() {
setTimeout('$(".issue-btn-w a").attr("target","_self");', 2000 );
//setTimeout('$(".module-cmt-footer").css("display","none");', 1000 );
//$(".module-cmt-footer").css("display","none");
})();