// 高速下载功能deeplink
(function(){
  var Downloader = {
    getBundleUrl : function(sid) {
        var channel = 19;
        if (location.href.indexOf('from=qing') >= 0) {
            channel = 20;
        }
        var apkUrl = 'http://openbox.mobilem.360.cn/SpeedDownload/getSpeedUrl2?from=' + channel + '&appid=' + sid;
        return apkUrl;
    },
    init:function(){
      var self = this;
      $(document).on('click', '.js-download-zs', function(e){
        e.preventDefault();
        var sid = $(this).data('sid');
        var name= $(this).data('name');
        var logo= $(this).data('logo');
        var url= $(this).data('url');
        var deeplinkUrl ='qihoodownload://downloadlist?&start_type=123456&from=wap&url='+url+'&icon='+logo+'&name='+encodeURIComponent(name)+'&ref=ccc&log=aaa=1&quit_when_back=false';
        console.log(deeplinkUrl)
        window.location.href = deeplinkUrl
        window.dTimeout = setTimeout(function() {
          var bundleUrl = self.getBundleUrl(sid)
          window.location.href = bundleUrl
        }, 2000)
        document.addEventListener('webkitvisibilitychange', function(){
            if (document.hidden || document.webkitHidden) {
                console.log('下载被取消')
                clearTimeout(window.dTimeout)
            }
        })
        window.onblur = function () {
            console.log('下载被取消')
            clearTimeout(window.dTimeout)
        }
      })

    }
  }
  Downloader.init();
})();
