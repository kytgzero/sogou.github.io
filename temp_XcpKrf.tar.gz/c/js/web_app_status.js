/**
 * @file APP下载状态检测
 * 针对好搜APP与360手机浏览器环境
 * 
 */

(function(){

var ua = navigator.userAgent;
var support = /(360 Aphone|mso_app)/i.test(ua);
var listeners = {};
var founded = {};
var fired = {};
var loopTimer;

var checker = {
    start : function() {
        if (!support) return;

        loopTimer && clearInterval(loopTimer);
        loopTimer = setInterval(function loop(){
            if (window.openinapp_packagename_list) {
                for (var apk in listeners) {
                    // 在本地安装列表中
                    if (openinapp_packagename_list[apk]) {
                        founded[apk] = 1;

                        checker.fireListener(apk, true);
                    }

                    // 上一次出现过，说明卸载了
                    else if (founded[apk]) {
                        checker.fireListener(apk, false);
                        founded[apk] = false;
                    }
                }
            }
        }, 100);
    },

    // todo: 支持批量监听
    listen : function(apk, callback) {
        if (listeners[apk]) {
            listeners[apk].push(callback);
        } else {
            listeners[apk] = [callback];
        }
    },

    fireListener : function(apk, installed) {
        var callbacks = listeners[apk];

        // 如果这次状态与上次相同，则不fire
        if (fired[apk] && fired[apk]['prev'] === installed) {
          return;
        }
        fired[apk] = {prev : installed};

        for (var i = 0, len = callbacks.length; i < len; i++) {
            try {
              callbacks[i](installed);
            } catch(e) {
              window.console && console.log('WebAppStatusMgr:' + e);
            }
        }
    }
};


window.WebAppStatusMgr = checker;

})();


/**
WebAppStatusMgr.listen('xxx', function(installed){
    if (installed) {
        alert('安装成功');
    }
});

WebAppStatusMgr.start();

*/