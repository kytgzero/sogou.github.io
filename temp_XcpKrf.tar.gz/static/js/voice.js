;
(function ($, win, doc) {
    $.extend({
        voice: function (options) {
            var lastCurrentId;
            var isPlay = false;
            var isLive = false;
            var lastIsLive;
            var frist = true;

            this.volume = 0.5;
            this.newList;
            this.newListLen;
            var fakeCurrentIndex;
            this.realCurrentIndex = 0

            var html = '<div id="voice">'+
                          '<div class="voice">' +
                            '<div class="controller hiRadio">' +
                            '<div class="middle">' +
                            '<div class="center">' +
                            '<div class="progress-bar">' +
                            '<div class="progress-bar_inner">' +
                            '<div class="progress-bar_handle"></div>' +
                            '</div>' +
                            '</div>' +
                            '<div class="currenttitle"></div>' +
                            '<div class="time">' +
                            '<span class="currenttime">00:00</span>/<span class="total">00:00</span>' +
                            '</div>' +
                            '</div>' +
                            '</div>' +
                            '<div class="left">' +
                            '<div class="prev"></div>' +
                            '<div class="play"></div>' +
                            '<div class="next"></div>' +
                            '</div>' +
                            '<div class="right">' +
                            '<div class="share btn_towcode"></div>' +
                            '<div class="volume">' +
                            '<div class="mute"></div>' +
                            '<div class="progress">' +
                            '<div class="progress_inner">' +
                            '<div class="progress_handle"></div>' +
                            '</div>' +
                            '</div>' +
                            '</div>' +
                            '</div>' +
                            '</div>' +
                          '</div>'+
                          '<div class="blank"></div>'
                        '</div>';
            var $dom = $(html)

            this.eles = {
                btnPlay: $('.play', $dom),
                prevBtn: $('.prev', $dom),
                nextBtn: $('.next', $dom),
                muteBtn: $('.mute', $dom),
                totalTime: $('.total', $dom),
                currentTime: $('.currenttime', $dom),
                currentTitle: $('.currenttitle', $dom),
                volumeProgress: $('.progress', $dom),
                volumeProgressInner: $('.progress_inner', $dom),
                volumeHand: $('.progress_handle', $dom),
                shareBtn: $('.btn_towcode', $dom),
                audioProgress: $('.progress-bar', $dom),
                audioProgressInner: $('.progress-bar_inner', $dom),
                audioProgressHand: $('.progress-bar_handle', $dom)
            }

            this.eles.shareBtn.on('click', function(){
              if ($(this).html() === "") {
                $(this).append('<div class="towCode"></div>')
              } else {
                $(this).empty()
              }

              return false;
            })

            var _x;
            var _move = false;
            var currentHanlder;
            var volumeProgressWidth;
            var audioProgressWidth;


            this.init = function () {
                $(doc.body).append($dom)
                volumeProgressWidth = this.eles.volumeProgress.width()
                audioProgressWidth = this.eles.audioProgress.width()

                this.api = new HiRadio();
                this.api.setVolume(this.volume)
                this.api.media.addEventListener('loadstart', this.audioEvents.bind(this))
                this.api.media.addEventListener('play', this.audioEvents.bind(this))
                this.api.media.addEventListener('pause', this.audioEvents.bind(this))
                this.api.media.addEventListener('ended', this.audioEvents.bind(this))
                this.api.media.addEventListener('error', this.audioEvents.bind(this))
                this.api.media.addEventListener('volumechange', this.audioEvents.bind(this))
            }

            this.load = function (options) {
                if (frist) {
                    this.bindDOM();
                    frist = false
                }
                if (options.currentIndex == lastCurrentId && options.isLive == lastIsLive) {
                    if (isPlay) {
                        this.api.pause()
                        return false
                    }
                } else {
                    if (isPlay) {
                        this.api.pause()
                    }
                }


                this.eles.volumeProgressInner.css({
                    width: this.volume * 100 + '%'
                })

                this.newListLen = options.urls.length
                this.newList = options.urls

                this.realCurrentIndex = 0
                this.eles.currentTime.text("00:00")
                this.eles.totalTime.text("00:00")
                this.eles.audioProgressInner.css({
                    width: 0
                })
                if (options.isLive) {
                    // 是直播
                    this.eles.currentTitle.text('正在直播:' + this.newList[this.realCurrentIndex].title)
                    this.eles.audioProgressHand.off('mousedown', this.mousedownHanlder.bind(this))
                    // this.api.media.removeEventListener('loadedmetadata', this.audioEvents.bind(this))
                    // this.api.media.removeEventListener('timeupdate', this.audioEvents.bind(this))
                } else {
                    // 不是直播，才有进度条，当前时间和总时间
                    // 有可能是MP3，也有可能是口播m3u8
                    this.eles.currentTitle.text('正在播放:' + this.newList[this.realCurrentIndex].title)
                    this.eles.audioProgressHand.on('mousedown', this.mousedownHanlder.bind(this))
                    this.api.media.addEventListener('loadedmetadata', this.audioEvents.bind(this))
                    this.api.media.addEventListener('timeupdate', this.audioEvents.bind(this))
                }
                isLive = options.isLive
                var list = $.map(this.newList, function (item) {
                    return item.url
                })
                //console.log('list', list)
                this.api.load(list)
                this.api.play()
                fakeCurrentIndex = options.currentIndex
                lastCurrentId = options.currentIndex
                lastIsLive = options.isLive

            }

            this.elesHandler = function (e) {
                var $target = $(e.target)
                if ($target.hasClass('pause')) {
                    this.api.pause()
                } else {
                    this.api.play()
                }
                options.changeChannel && typeof options.changeChannel == 'function' ? options.changeChannel({
                    currentIndex: fakeCurrentIndex,
                    isLive: isLive,
					          ele: e
                }) : null
                return false
            };

            this.next = function (e) {
                this.api.next()
                // 给外部是假的
                if (fakeCurrentIndex == this.newListLen - 1) {
                    fakeCurrentIndex = 0
                } else {
                    fakeCurrentIndex += 1
                }
                // 内部使用是真的
                if (this.realCurrentIndex == this.newListLen - 1) {
                    this.realCurrentIndex = 0
                } else {
                    this.realCurrentIndex += 1
                }
                if (isLive) {
                    this.eles.currentTitle.text('正在直播:' + this.newList[this.realCurrentIndex].title)
                } else {
                    this.eles.currentTitle.text('正在播放:' + this.newList[this.realCurrentIndex].title)
                }

                options.changeChannel && typeof options.changeChannel == 'function' ? options.changeChannel({
                    currentIndex: fakeCurrentIndex,
                    isLive: isLive,
					          ele: e
                }) : null

                lastCurrentId = fakeCurrentIndex

                return false
            }

            this.prev = function (e) {
                this.api.previous()
                // 外部使用是假的
                if (fakeCurrentIndex == 0) {
                    fakeCurrentIndex = this.newListLen - 1
                } else {
                    fakeCurrentIndex -= 1
                }
                // 内部使用是真的
                if (this.realCurrentIndex == 0) {
                    this.realCurrentIndex = this.newListLen - 1
                } else {
                    this.realCurrentIndex -= 1
                }
                if (isLive) {
                    this.eles.currentTitle.text('正在直播:' + this.newList[this.realCurrentIndex].title)
                } else {
                    this.eles.currentTitle.text('正在播放:' + this.newList[this.realCurrentIndex].title)
                }
                options.changeChannel && typeof options.changeChannel == 'function' ? options.changeChannel({
                    currentIndex: fakeCurrentIndex,
                    isLive: isLive,
					          ele: e
                }) : null

                lastCurrentId = fakeCurrentIndex

                return false
            }

            this.trigger = function () {
                if (this.api.getVolume() != 0) {
                    this.api.setVolume(0)
                } else {
                    this.api.setVolume(this.volume)
                }
            }

            this.share = function (e) {
                var number = $(e.target).children().length
                $('.btn_towcode').empty();
                if (number == 0) {
                    $(e.target).append('<div class="towCode"></div>')
                }
            }

            this.audioEvents = function (event) {
                switch (event.type) {
                    case 'loadstart':
                        //console.log('loadstart')
                        break;
                    case 'loadedmetadata':
                        if (!isLive) {
                            this.eles.totalTime.text(timeStyle(this.api.media.duration))
                        }
                        break;
                    case 'play':
                        this.eles.btnPlay.addClass('pause')
                        isPlay = true
                        break;
                    case 'pause':
                        this.eles.btnPlay.removeClass('pause')
                        isPlay = false
                        break;
                    case 'volumechange':
                        var currentVolume = this.api.getVolume()
                        if (currentVolume == 0) {
                            this.eles.muteBtn.addClass('muted')
                            this.eles.volumeProgressInner.css({
                                width: 0
                            });
                        } else {
                            this.eles.muteBtn.removeClass('muted')
                            this.eles.volumeProgressInner.css({
                                width: currentVolume * 100 + '%'
                            });
                        }
                        break;
                    case 'ended':
                        this.eles.muteBtn.removeClass('muted')
                        var currentUrl = this.newList[this.realCurrentIndex].url
                        isPlay = false
                        if (!isLive && currentUrl.indexOf('.m3u8') == -1) {
                            options.changeChannel && typeof options.changeChannel == 'function' ? options.changeChannel({
                                currentIndex: fakeCurrentIndex,
                                isLive: isLive,
								ele: event
                            }) : null
                        }
                        break;
                    case 'timeupdate':
                        if (!isLive) {
                            this.eles.currentTime.text(timeStyle(this.api.media.currentTime))
                            this.eles.audioProgressInner.css({
                                width: this.api.media.currentTime / this.api.media.duration * 100 + "%"
                            });
                        }
                        break;
                    case 'error':
                        alert('音频加载错误！')
                        break;
                    default:
                        break
                }
            };


            this.mousedownHanlder = function (e) {
                currentHanlder = $(e.target)
                //console.log(currentHanlder)
                _move = true
                _x = e.pageX;
                currentHanlder.data('_currentdistance', currentHanlder.position().left + currentHanlder.width() / 2)
            }

            this.mousemoveHanlder = function (e) {
                if (_move) {
                    var diff = e.pageX - _x;
                    var sum = currentHanlder.data('_currentdistance') + diff

                    if (sum < 0) {
                        sum = 0
                    }

                    if (currentHanlder.hasClass('progress_handle')) {
                        //console.log('sum', sum)
                        //console.log('volumeProgressWidth', volumeProgressWidth)
                        if (sum > volumeProgressWidth) {
                            sum = volumeProgressWidth
                        }

                        var percent = sum / volumeProgressWidth
                        //console.log(percent)
                        this.api.setVolume(percent)
                    }
                    if (currentHanlder.hasClass('progress-bar_handle')) {
                        if (sum > audioProgressWidth) {
                            sum = audioProgressWidth
                        }

                        var percent = sum / audioProgressWidth
                        // 从指定的时间点开始播放
                        this.api.seek(this.api.media.duration * percent)
                    }

                }
            }

            this.mouseupHanlder = function (e) {
                _move = false
            }

            this.bindDOM = function () {
                this.eles.btnPlay.on('click', this.elesHandler.bind(this))
                this.eles.muteBtn.on('click', this.trigger.bind(this))
                this.eles.prevBtn.on('click', this.prev.bind(this))
                this.eles.nextBtn.on('click', this.next.bind(this))
                
                this.eles.volumeHand.on('mousedown', this.mousedownHanlder.bind(this))
                $(doc).on('mousemove', this.mousemoveHanlder.bind(this))
                $(doc).on('mouseup', this.mouseupHanlder.bind(this))
            }



            this.init();

            return this
        }
    });


    function timeStyle(value) {
        var result = parseInt(value)
        var h = Math.floor(result / 3600) < 10 ? '0' + Math.floor(result / 3600) : Math.floor(result / 3600);
        var m = Math.floor((result / 60 % 60)) < 10 ? '0' + Math.floor((result / 60 % 60)) : Math.floor((result / 60 % 60));
        var s = Math.floor((result % 60)) < 10 ? '0' + Math.floor((result % 60)) : Math.floor((result % 60));
        var res = '';
        if (h !== '00') {
            res = h + ':'
        }
        res += m + ':'
        res += s
        return res;
    }


})(jQuery || window.jQuery, window, document);