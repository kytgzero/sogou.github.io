; (function (undefined) {
  var mediaObj = {};
  var params = getSearchParameters();
  var objectId = params['id'];
  var mediaDuration = 0;
  function getSearchParameters() {
    var prmstr = window.location.search.substr(1);
    return prmstr != null && prmstr != "" ? transformToAssocArray(prmstr) : {};
  }

  function transformToAssocArray(prmstr) {
    var params = {};
    var prmarr = prmstr.split("&");
    for (var i = 0; i < prmarr.length; i++) {
      var tmparr = prmarr[i].split("=");
      params[tmparr[0]] = tmparr[1];
    }
    return params;
  }
  window.hiRadio = function (options) {
    var _this = this;
    var api, eles;
    var instance = [];
    var currentIndex = 0;
    var mobile = /iPad|iPhone|iPod|Android/i.test(navigator.userAgent);
    var arg = arguments[0];
    var isQuite = false;

    function isInclude(name) {

      var js = /js$/i.test(name);

      var es = document.getElementsByTagName(js ? 'script' : 'link');

      for (var i = 0; i < es.length; i++)

        if (es[i][js ? 'src' : 'href'].indexOf(name) != -1) return true;

      return false;

    }
    function dynamicLoadCss(url) {
      var head = document.getElementsByTagName('head')[0];
      var link = document.createElement('link');
      link.type = 'text/css';
      link.rel = 'stylesheet';
      link.href = url;
      head.appendChild(link);
    }
    if (!isInclude("hiradio.css")) {
      dynamicLoadCss('https://jscache.cnr.cn/player/test/hiradio.css')
    }
    function each(obj, fn) {
      if (!obj) {
        return;
      }
      var name, i = 0,
        length = obj.length;

      // object
      if (length === undefined) {
        for (name in obj) {
          if (fn.call(obj[name], name, obj[name]) === false) {
            break;
          }
        }
      } else {
        for (var value = obj[0]; i < length && fn.call(value, i, value) !== false; value = obj[++i]) { }
      }
      return obj;
    }
    function select(query) {
      var index = query.indexOf(".");
      if (index != -1) {
        var tag = query.slice(0, index) || "*";
        var klass = query.slice(index + 1, query.length);
        var els = [];
        each(document.getElementsByTagName(tag), function () {
          if (this.className && this.className.indexOf(klass) != -1) {
            els.push(this);
          }
        });
        return els;
      }
    }
    function hasClassName(obj, name) {
      var tmpName = obj.className;
      var tmpReg = new RegExp(name, 'g');
      if (tmpReg.test(tmpName)) {
        return true;
      } else {
        return false;
      }
    }
    function addClassName(el, cls) {
      if ('classList' in el) {
        el.classList.add(cls);
      } else {
        var preCls = el.className;
        var newCls = preCls + ' ' + cls;
        el.className = newCls;
      }
      return el;
    }
    function removeClassName(elem, className) {
      elem.className = elem.className.replace(new RegExp("(^|\\s)" + className + "(?=(\\s|$))", "g"), '');
    }
    function indexOF(el) {
      if (!el) return -1;
      return Array.prototype.slice.call(document.querySelectorAll('.HiRadioPlayer')).indexOf(el);
    }
    function playRadio(id) {
      for (var i = 0; i < instance.length; i++) {
        if (instance[i].id == id) {
          if (instance[i].isMove == false) {
            api.load(instance[i].playUrl);
            instance[i].isMove = true;
          }
          loadStream();
          currentIndex = i;
        } else {
          instance[i].isMove = false;
          removeClassName(instance[i].querySelectorAll('.playBtn')[0], 'pause');
          instance[i].currentTime = time_to_sec(instance[i].querySelectorAll('.cur_time')[0].textContent);
        }
      }
    }
    function timeStyle(value) {
      var result = parseInt(value)
      var h = Math.floor(result / 3600) < 10 ? '0' + Math.floor(result / 3600) : Math.floor(result / 3600);
      var m = Math.floor((result / 60 % 60)) < 10 ? '0' + Math.floor((result / 60 % 60)) : Math.floor((result / 60 % 60));
      var s = Math.floor((result % 60)) < 10 ? '0' + Math.floor((result % 60)) : Math.floor((result % 60));
      var res = '';
      if (h !== '00') {
        res = h + ':'
      }
      res += m + ':'
      res += s
      return res;
    }
    function time_to_sec(time) {
      var s = '';
      if (time.split(':').length == 3) {
        var hour = time.split(':')[0];
        var min = time.split(':')[1];
        var sec = time.split(':')[2];
        s = Number(hour * 3600) + Number(min * 60) + Number(sec);
      } else {
        var min = time.split(':')[0];
        var sec = time.split(':')[1];
        s = Number(min * 60) + Number(sec);
      }
      return s;
    }
    function makeId() {
      return "_" + ("" + Math.random()).slice(2, 10);
    }
    function bindDOM() {
      var _this = this;
      for (var i = 0; i < eles.btnPlay.length; i++) {
        eles.btnPlay[i].addEventListener('click', _this.elesHandler.bind(_this), false)
      }
      for (var j = 0; j < eles.playBar.length; j++) {
        eles.playBar[j].addEventListener('click', _this.elesHandler.bind(_this), false)
      }

    }
    function controlAudio() {
      var audios = document.getElementsByTagName("audio");
      function pauseAll() {
        var self = this;
        [].forEach.call(audios, function (i) {
          i !== self && i.pause();
        })
      }
      [].forEach.call(audios, function (i) {
        i.addEventListener("play", pauseAll.bind(i));
      })
    }
    function init(wrapper) {
      var self = this;
      wrapper.isMove = false;
      wrapper.volume = 0.5;
      wrapper.currentTime = 0;
      wrapper.id = 'CNR' + makeId();
      if (wrapper.getAttribute('data-url')) {
        wrapper.playUrl = wrapper.getAttribute('data-url');
      }
      if (!mobile) {
        wrapper.innerHTML = '<div class="record"></div><div class="start_tip"></div><span class="playBtn" id="' + wrapper.id + '"></span>' +
          '<div class="wrapper_bar" onclick="changeTime(this,event)"><div class="play_bar">' +
          '<div class="progress_bar"></div>' +
          ' <div class="progress_dot"></div></div>' +
          ' </div>' +
          '<div class="cur_time">00:00/</div>' +
          '<div class="duration">00:00</div>' +
          '<div class="vol_wrapper" onclick="changeVol(this,event)">' +
          '<div class="vol_bar">' +
          '<div class="vol_progress"></div>' +
          '<div class="vol_dot"></div>' +
          '</div>' +
          '</div>' +
          //'<div class="volume"></div>' +
          '<div class="volume" onclick="setQuite(this)"></div>'
          ;

      } else {
        wrapper.innerHTML = '<audio src="' + wrapper.playUrl + '" controls controlsList="nodownload"></audio>';
        addClassName(wrapper, 'phone_wrap');
        controlAudio();
      }
      eles = {
        btnPlay: document.querySelectorAll('.playBtn'),
        playBar: document.querySelectorAll('.wrapper_bar'),

      }

      return wrapper;
    }
    this.initRadio = function () {
      api = new HiRadio();
      api.media.addEventListener('loadstart', this.audioEvents.bind(this))
      api.media.addEventListener('loadedmetadata', this.audioEvents.bind(this))
      api.media.addEventListener('play', this.audioEvents.bind(this))
      api.media.addEventListener('pause', this.audioEvents.bind(this))
      api.media.addEventListener('ended', this.audioEvents.bind(this))
      api.media.addEventListener('timeupdate', this.audioEvents.bind(this))
      api.media.addEventListener('error', this.audioEvents.bind(this))
      bindDOM();
    };
    this.loadStream = function () {
      api.play();
    }
    this.elesHandler = function (e) {
      var target = e.target;
      var index = indexOF(target.parentNode);
      if (hasClassName(target, 'playBtn')) {
        if (hasClassName(target, 'pause')) {
          api.pause()
        } else {
          document.querySelectorAll('.start_tip')[index].style.display = "none";
          target.parentNode.querySelectorAll(".volume")[0].style.opacity = 1;
          api.setVolume(instance[index].volume);
          isQuite = false;
          playRadio(target.id);
        }
      }
      return false
    };

    window.changeTime = function (a, event) {
      var target = a;
      var index = indexOF(target.parentNode);
      if (instance[index].isMove == true) {
        var play_bar = parseFloat(getComputedStyle(target, null).width.replace("px", ""));
        startX = (event.pageX - target.getBoundingClientRect().left + document.body.scrollLeft < 0 ? 0 : event.pageX - target.getBoundingClientRect().left + document.body.scrollLeft) > play_bar ? play_bar : event.pageX - target.getBoundingClientRect().left + document.body.scrollLeft < 0 ? 0 : event.pageX - target.getBoundingClientRect().left + document.body.scrollLeft;
        target.querySelectorAll(".progress_bar")[0].style.width = (startX / play_bar).toFixed(2) * 100 + "%";
        target.querySelectorAll(".progress_dot")[0].style.left = parseFloat(getComputedStyle(target.querySelectorAll('.progress_bar')[0], null).width.replace("px", "")) - 5 + 'px';
        api.seek(startX / play_bar * api.media.duration);
        api.media.currentTime = startX / play_bar * api.media.duration;
      }
    };
    window.changeVol = function (a, event) {
      var target = a;
      var index = indexOF(target.parentNode);
      if (instance[index].isMove == true) {
        target.parentNode.querySelectorAll(".volume")[0].style.opacity = 1;
        var play_bar = parseFloat(getComputedStyle(target, null).width.replace("px", ""));
        startX = (event.pageX - target.getBoundingClientRect().left + document.body.scrollLeft < 0 ? 0 : event.pageX - target.getBoundingClientRect().left + document.body.scrollLeft) > play_bar ? play_bar : event.pageX - target.getBoundingClientRect().left + document.body.scrollLeft < 0 ? 0 : event.pageX - target.getBoundingClientRect().left + document.body.scrollLeft;
        startX = startX - 10;
        api.setVolume(Math.ceil(startX / 10) / 10)
        instance[index].volume = api.getVolume();
        target.querySelectorAll(".vol_progress")[0].style.width = instance[index].volume * 100 + "%";
        target.querySelectorAll(".vol_dot")[0].style.left = parseFloat(getComputedStyle(target.querySelectorAll('.vol_progress')[0], null).width.replace("px", "")) - 6 + 'px';
      }
    };
    window.setQuite = function (a) {
      var target = a;
      var index = indexOF(target.parentNode);
      if (instance[index].isMove == true) {
        if (isQuite) {
          isQuite = false;
          api.setVolume(instance[index].volume);
          target.parentNode.querySelectorAll(".volume")[0].style.opacity = 1;
          removeClassName(target, 'quite');
        } else {
          instance[index].volume = api.getVolume();
          isQuite = true;
          api.setVolume(0);
          target.parentNode.querySelectorAll(".volume")[0].style.opacity = 0.5;
          addClassName(target, 'quite');
        }
      }

    };
    this.audioEvents = function (event) {
      switch (event.type) {
        case 'loadstart':
          if (instance[currentIndex].currentTime && instance[currentIndex].currentTime > 0) {
            document.querySelectorAll('.cur_time')[currentIndex].textContent = timeStyle(instance[currentIndex].currentTime) + '/'
          }
          break;
        case 'loadedmetadata':
          if (instance[currentIndex].currentTime && instance[currentIndex].currentTime > 0) {
            api.seek(instance[currentIndex].currentTime);
            api.media.currentTime = instance[currentIndex].currentTime;
          }
          document.querySelectorAll('.duration')[currentIndex].textContent = timeStyle(api.media.duration);
          mediaDuration = api.media.duration * 1000;
          mediaObj.duration = mediaDuration;
          break;
        case 'play':
          addClassName(document.querySelectorAll('.playBtn')[currentIndex], 'pause');
          mediaObj = {
            "appId": "ygwpc",
            "createTime": getYMDHMS(new Date()),
            "progress": api.media.currentTime * 1000,
            "duration": mediaDuration,
            "info": api.url,
            "operationType": "b3",
            "objectId": objectId,
            "objectType": $('.HiRadioPlayer').attr('data-type'),
            "parentId": $('.HiRadioPlayer').attr('data-parentId'),
          }
          break;
        case 'pause':
          removeClassName(document.querySelectorAll('.playBtn')[currentIndex], 'pause')
          break;
        case 'ended':
          removeClassName(document.querySelectorAll('.playBtn')[currentIndex], 'pause');
          document.querySelectorAll('.cur_time')[currentIndex].textContent = "00:00/";
          document.querySelectorAll('.progress_bar')[currentIndex].style.width = '0%';
          document.querySelectorAll('.progress_dot')[currentIndex].style.left = '-5px';
          instance[currentIndex].isMove = false;
          instance[currentIndex].currentTime = 0;
          break;
        case 'timeupdate':
          document.querySelectorAll('.cur_time')[currentIndex].textContent = timeStyle(api.media.currentTime) + '/';
          document.querySelectorAll('.progress_bar')[currentIndex].style.width = api.media.currentTime / api.media.duration * 100 + "%";
          document.querySelectorAll('.progress_dot')[currentIndex].style.left = parseFloat(getComputedStyle(document.querySelectorAll('.progress_bar')[currentIndex], null).width.replace("px", "")) - 5 + 'px'
          break;
        case 'error':
          alert('播放错误！')
          break;
        default:
          break
      }
    };

    if (typeof arg == 'string') {
      if (arg.indexOf(".") != -1) {
        each(select(arg), function () {
          instance.push(new init(this));
        });
        initRadio();
      }
    }

   setInterval(function () {
      var currentTime = api.media.currentTime * 1000;
      if (currentTime != mediaObj.progress && mediaObj.appId) {
        mediaObj.progress = currentTime;
        var xhr = new XMLHttpRequest();
        xhr.open("post", "https://iprofile.cnr.cn/businessAnalysis");
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
        xhr.setRequestHeader("accesstoken", "6vA437b6vqetx6loJh/tAkYGbs82bvaelRmr+toQep9HsOiUQMzSTnnHIS9gTRQUrvr5e5y63yeEZhDZg3WRen7p6pdqevDfwJaLUfHjPS4=");
        xhr.onreadystatechange = function () {
          if (xhr.status == 200) {
            console.log('success');
          }
        }
        xhr.send(JSON.stringify(mediaObj));
      }
    }, 10000)

    window.getYMDHMS = function (timestamp) {
      let time = timestamp
      let year = time.getFullYear()
      let month = time.getMonth() + 1
      let date = time.getDate()
      let hours = time.getHours()
      let minute = time.getMinutes()
      let second = time.getSeconds()

      if (month < 10) { month = '0' + month }
      if (date < 10) { date = '0' + date }
      if (hours < 10) { hours = '0' + hours }
      if (minute < 10) { minute = '0' + minute }
      if (second < 10) { second = '0' + second }
      return year + '-' + month + '-' + date + ' ' + hours + ':' + minute + ':' + second;
    }

    return this;
  }

}());
