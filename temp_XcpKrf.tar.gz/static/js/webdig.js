(function(w,d,g,r){
    w['_wd_o']=r;
    w[r]=w[r]||function(){arguments.t=1*new Date(),(w[r].q=w[r].q||[]).push(arguments);};
    var a=d.createElement('script'),m=d.getElementsByTagName('script')[0];
    a.async=1;
    a.src=g;m.parentNode.insertBefore(a,m);
  })(window,document,'//cl2.webterren.com/webdig.js?z=7','_wa');

 _wa('wd_paramtracker', '_wdxid=000000000000000000000000000000000000000000');